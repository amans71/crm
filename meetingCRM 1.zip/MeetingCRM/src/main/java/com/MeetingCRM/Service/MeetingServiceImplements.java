package com.MeetingCRM.Service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.MeetingCRM.Exceptions.MeetingCreationFailedException;
import com.MeetingCRM.Exceptions.MeetingNotFoundException;
import com.MeetingCRM.Exceptions.MeetingStatusUpdateFailedException;
import com.MeetingCRM.Model.Meeting;
import com.MeetingCRM.Repository.MeetingManagementRepository;
import com.MeetingCRM.payload.UserDTO;

@Service
public class MeetingServiceImplements implements MeetingManagementService {
	@Autowired
	MeetingManagementRepository repo;
	
	Logger logger = LoggerFactory.getLogger(MeetingServiceImplements.class);
	
	@Autowired
	private RestTemplate restTemplate;

//	Find all meetings
	public List<Meeting> viewAllMeetings() {
		List<Meeting> allMeetings = repo.findAll();
		for (Meeting meet : allMeetings) {
			UserDTO user = restTemplate.getForObject("http://localhost:8080/api/users/getUser/" + meet.getUserId() , UserDTO.class);
			meet.setUser(user);
		}
		return allMeetings;
	}
	
	
//	Find meeting by meeting ID
	public Meeting viewMeetingById(long meetingId) throws MeetingNotFoundException {
		Meeting meet = repo.findById(meetingId).orElseThrow(
				() -> new MeetingNotFoundException("Meeting ID not valid. Please enter a valid meeting ID.")
				);
		
//		Fetching user details of the above meeting by USER SERVICE
//		http://localhost:8080/api/users/getUser/{id}
		UserDTO user = restTemplate.getForObject("http://localhost:8080/api/users/getUser/" + meet.getUserId() , UserDTO.class);

		meet.setUser(user);
		
		return meet;
	}
	
	
//	Add a new meeting
	public String addMeeting(Meeting meeting) throws MeetingCreationFailedException {
		
//		To check that meeting start date should come before meeting end date
		if (meeting.getMeetingStartDate().isAfter(meeting.getMeetingEndDate())) {
			throw new MeetingCreationFailedException("Meeting start date should come before meeting end date.");
		}
			
		repo.save(meeting);
		return "Meeting added successfully.";
	}
	
	
//	Update meeting details
	public String updateDetails(long meetingId, Meeting meeting) throws MeetingStatusUpdateFailedException, MeetingNotFoundException {
		Meeting meet = repo.findById(meetingId).get();
		
//		To throw an exception is meeting is not found.
		if (meet == null)
			throw new MeetingNotFoundException("Meeting ID not valid. PLease enter a valid meeting ID.");
		
//		To check whether the meeting is completed or pending
		if (meet.getStatus().equals("Completed"))
			throw new MeetingStatusUpdateFailedException("Meeting already completed.");
		
//		To check that meeting start date should come before meeting end date
		if (meeting.getMeetingStartDate().isAfter(meeting.getMeetingEndDate())) {
			throw new MeetingStatusUpdateFailedException("Meeting start date should come before meeting end date.");
		}
		
//		To delete the meeting from database if the meeting status has been updated to "Cancelled".
		if (meeting.getStatus().equals("Cancelled")) {
			String result = deleteMeeting(meetingId);
			logger.info(result);
			return "Meeting has been removed as it was cancelled.";
		} else {
			meet.setMeetingStartDate(meeting.getMeetingStartDate());
			meet.setMeetingEndDate(meeting.getMeetingStartDate());
			meet.setStatus(meeting.getStatus());
			repo.save(meet);
		}
		
		return "Meeting details updated successfully.";
	}
	
	
//	Delete meeting details
	public String deleteMeeting(long meetingId) throws MeetingNotFoundException {
		Optional<Meeting> meet = repo.findById(meetingId);
		if (!meet.isPresent())
			throw new MeetingNotFoundException("Meeting ID not valid. Please enter a valid meeting ID.");
		repo.deleteById(meetingId);
		return "Meeting deleted successfully.";
	}
} 