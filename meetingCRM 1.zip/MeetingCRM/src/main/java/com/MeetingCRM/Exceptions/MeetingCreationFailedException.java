package com.MeetingCRM.Exceptions;

@SuppressWarnings("serial")
public class MeetingCreationFailedException extends Exception{
	public MeetingCreationFailedException(String message) {
		super(message);
	}
}
