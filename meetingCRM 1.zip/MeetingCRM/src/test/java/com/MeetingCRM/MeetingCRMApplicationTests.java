package com.MeetingCRM;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeetingCRMApplicationTests {

}
