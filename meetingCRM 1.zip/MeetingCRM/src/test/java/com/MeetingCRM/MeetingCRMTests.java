package com.MeetingCRM;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.client.RestTemplate;

import com.MeetingCRM.Exceptions.MeetingCreationFailedException;
import com.MeetingCRM.Exceptions.MeetingNotFoundException;
import com.MeetingCRM.Exceptions.MeetingStatusUpdateFailedException;
import com.MeetingCRM.Model.Meeting;
import com.MeetingCRM.Repository.MeetingManagementRepository;
import com.MeetingCRM.Service.MeetingServiceImplements;
import com.MeetingCRM.payload.UserDTO;

@ExtendWith(MockitoExtension.class)
public class MeetingCRMTests {
	@Mock
	MeetingManagementRepository meetingRepo;
	
	@Mock
	RestTemplate restTemplate;
	
	@InjectMocks
	MeetingServiceImplements meetingService;
	
	Meeting testMeeting;
	
	@BeforeEach
	void setUp() {
		testMeeting = new Meeting();
		testMeeting.setUserId(10);
        testMeeting.setMeetingStartDate(LocalDate.of(2024, 2, 7));
        testMeeting.setMeetingEndDate(LocalDate.of(2024, 2, 7));
        testMeeting.setStatus("Cancelled");
	}
	
	
//	For scheduleANewMeeting()
	@Test
	public void testScheduleMeeting() throws MeetingCreationFailedException {
		when(meetingRepo.save(any(Meeting.class))).thenReturn(testMeeting);
		
		assertNotNull(meetingService.addMeeting(testMeeting));
		verify(meetingRepo, times(1)).save(testMeeting);
	}
	
	
//	For findAllMeetings()
	@Test
	public void testFindAllMeetings() {
		List<Meeting> mockList = Arrays.asList(new Meeting(), new Meeting());
		when(meetingRepo.findAll()).thenReturn(mockList);
		
		List<Meeting> actualList = meetingService.viewAllMeetings();
		
		assertEquals(mockList, actualList);
		assertThat(actualList).hasSizeGreaterThan(0);
	}
	
	
//	For findMeetingById()
	@Test
	public void testFindMeetingById() throws MeetingNotFoundException {
	    long meetingId = 123;
        UserDTO expectedUser = new UserDTO();
        expectedUser.setUserId(10);
        when(meetingRepo.findById(meetingId)).thenReturn(Optional.of(testMeeting));
        when(restTemplate.getForObject(eq("http://USERCRM/api/users/getUser/" + testMeeting.getUserId()), eq(UserDTO.class)))
                .thenReturn(expectedUser);

        Meeting actualMeeting = meetingService.viewMeetingById(meetingId);

        assertEquals(testMeeting, actualMeeting);
        assertEquals(expectedUser, actualMeeting.getUser());
	}
	
	
//	For updateMeeting()
	@Test
	public void testUpdateMeeting() throws MeetingStatusUpdateFailedException, MeetingNotFoundException {
		long meetingId = 123;

        Meeting updatedMeeting = new Meeting();
        updatedMeeting.setMeetingId(meetingId);
        updatedMeeting.setMeetingStartDate(LocalDate.of(2024, 2, 20));
        updatedMeeting.setMeetingEndDate(LocalDate.of(2024, 2, 20));
        updatedMeeting.setStatus("Completed");

        when(meetingRepo.findById(meetingId)).thenReturn(Optional.of(testMeeting));

        String result = meetingService.updateDetails(meetingId, updatedMeeting);

        assertEquals("Meeting details updated successfully.", result);
        assertEquals(updatedMeeting.getMeetingStartDate(), testMeeting.getMeetingStartDate());
        assertEquals(updatedMeeting.getMeetingEndDate(), testMeeting.getMeetingEndDate());
        assertEquals(updatedMeeting.getStatus(), testMeeting.getStatus());
        verify(meetingRepo).save(testMeeting);

	}
	
	
//	For deleteMeeting()
	@Test
	public void testDeleteMeeting() throws MeetingNotFoundException {
		when(meetingRepo.findById(testMeeting.getMeetingId())).thenReturn(Optional.of(testMeeting));

        String result = meetingService.deleteMeeting(testMeeting.getMeetingId());

        verify(meetingRepo, times(1)).deleteById(testMeeting.getMeetingId());
        assertEquals("Meeting deleted successfully.", result);
	}
	
}