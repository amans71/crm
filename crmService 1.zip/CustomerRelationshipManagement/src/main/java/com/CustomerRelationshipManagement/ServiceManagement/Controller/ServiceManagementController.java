package com.CustomerRelationshipManagement.ServiceManagement.Controller;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CustomerRelationshipManagement.ServiceManagement.Model.ServiceManagement;
import com.CustomerRelationshipManagement.ServiceManagement.Service.ServiceManagementService;

@RestController
@RequestMapping("/api/services")
public class ServiceManagementController {
	@Autowired
	ServiceManagementService service;
	
	//To Add New Service
	@PostMapping("/add")
	public boolean addService(ServiceManagement serviceManagementObj) {
		return service.addService(serviceManagementObj);
	}
	
	// TO VIEW AVAILABLE SERVICES
	@GetMapping("/view")
	public List<ServiceManagement> viewAll(){
		return service.viewAllServices();
	}
	
	//Delete The Service
	@DeleteMapping("/delete/{serviceId}")
	public String deleteService(@PathVariable Integer serviceId) {
		return service.deleteService(serviceId);
	}
	
	//Update Service
	@PutMapping("/update/{serviceId}")
	public String updateService(@PathVariable Integer serviceId,@RequestBody ServiceManagement serviceManagementObj) {
			return service.updateService(serviceId,serviceManagementObj);
	}
	
	
	
	
}
