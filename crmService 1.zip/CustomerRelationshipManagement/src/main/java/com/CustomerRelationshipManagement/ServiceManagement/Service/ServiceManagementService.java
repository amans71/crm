package com.CustomerRelationshipManagement.ServiceManagement.Service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CustomerRelationshipManagement.ServiceManagement.Model.ServiceManagement;

import com.CustomerRelationshipManagement.ServiceManagement.Repository.ServiceManagementRepository;

@Service
public class ServiceManagementService implements ServiceManagementServiceImpl{
	@Autowired
	ServiceManagementRepository serviceRepo;
	
	List<ServiceManagement> serviceList=new ArrayList<ServiceManagement>();
	
	public void setServiceList(List<ServiceManagement> serviceList) {
		this.serviceList=serviceList;
	}
	
	public List<ServiceManagement> getServiceList(){
		return serviceList;
	}
	
	
	//Add new Connections
	public boolean addService(ServiceManagement serviceManagementObj) {
		return serviceList.add(serviceManagementObj);
	}
	
	//View List of Services
	public List<ServiceManagement> viewAllServices(){
		return serviceList;
	}
	
	// Update the Services
	public String updateService(int serviceId,ServiceManagement serviceManagementObj) {
		ServiceManagement existingServiceManagementObj=serviceRepo.getById(serviceId);
		if(existingServiceManagementObj==null) {
			return "Update Failed";
		}
		existingServiceManagementObj.setServiceId(serviceManagementObj.getServiceId());
		existingServiceManagementObj.setServiceName(serviceManagementObj.getServiceName());
		existingServiceManagementObj.setEstimatedDuration(serviceManagementObj.getEstimatedDuration());
		existingServiceManagementObj.setServiceType(serviceManagementObj.getServiceType());
		existingServiceManagementObj.setTeamMembersInvolved(serviceManagementObj.getTeamMembersInvolved());
		serviceRepo.save(existingServiceManagementObj);
		return "Data Is Updated Successfully";
		
	}
	
	//Delete Services
	public String deleteService(int serviceId) {
		serviceRepo.deleteById(serviceId);
		return "Service details deleted.";
	}
}
