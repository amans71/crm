package com.CustomerRelationshipManagement.ServiceManagement.Model;

import com.CustomerRelationshipManagement.UserManagement.Model.User;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Service")
public class ServiceManagement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int serviceId;

    @Column(nullable = false)
    private String serviceName;

    @Column(nullable = false)
    private int estimatedDuration;

//    @ElementCollection
    private int teamMembersInvolved;

    @Column(nullable = false)
    private String serviceType;

    @ManyToOne
    @JoinColumn(name = "userId")
    private User user;

   public ServiceManagement(String serviceName, int estimatedDuration,int teamMembersInvolved, String serviceType, User user) {
        super();
    	this.serviceName = serviceName;
        this.estimatedDuration = estimatedDuration;
        this.teamMembersInvolved = teamMembersInvolved;
        this.serviceType = serviceType;
        this.user = user;
    }
   public void setServiceId(int serviceId) {
	   this.serviceId=serviceId;
   }
    public int getServiceId() {
        return serviceId;
    }
    
    public void setServiceName(String serviceName) {
    	this.serviceName=serviceName;
    }
    public String getServiceName() {
        return serviceName;
    }
    
    public void setEstimatedDuration(int estimatedDuration) {
    	this.estimatedDuration=estimatedDuration;
    }
    
    public int getEstimatedDuration() {
        return estimatedDuration;
    }

    public void setTeamMembersInvolved(int teamMembersInvolved) {
    	this.teamMembersInvolved=teamMembersInvolved;
    }
    public int getTeamMembersInvolved() {
        return teamMembersInvolved;
    }
    
    public void setServiceType(String serviceType) {
    	this.serviceType=serviceType;
    }
    
    public String getServiceType() {
        return serviceType;
    }

    public User getUser() {
        return user;
    }

	@Override
	public String toString() {
		return "ServiceManagement [serviceId=" + serviceId + ", serviceName=" + serviceName + ", estimatedDuration="
				+ estimatedDuration + ", teamMembersInvolved=" + teamMembersInvolved + ", serviceType=" + serviceType
				+ ", user=" + user + "]";
	}

	
    
}
