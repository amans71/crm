package com.CustomerRelationshipManagement.ServiceManagement.Service;

import java.util.List;

import com.CustomerRelationshipManagement.ServiceManagement.Model.ServiceManagement;

public interface ServiceManagementServiceImpl {
	
	public boolean addService(ServiceManagement serviceManagementObj);
	
	public List<ServiceManagement> viewAllServices();
	
	public String updateService(int serviceId,ServiceManagement serviceManagementObj);
	
	public String deleteService(int serviceId);
	
	
}
