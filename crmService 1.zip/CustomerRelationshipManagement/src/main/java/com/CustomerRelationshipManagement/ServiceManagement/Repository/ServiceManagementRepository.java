package com.CustomerRelationshipManagement.ServiceManagement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.CustomerRelationshipManagement.ServiceManagement.Model.ServiceManagement;

public interface ServiceManagementRepository extends JpaRepository<ServiceManagement, Integer>{

}
